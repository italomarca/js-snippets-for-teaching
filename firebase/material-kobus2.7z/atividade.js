var repositorio = require('./aluno-repository')

repositorio.insereAtividade({
    titulo : "Oie",
    author : 'kobus',
    conteudo : "teste",
    data : new Date(),
    tipo : 1
})




